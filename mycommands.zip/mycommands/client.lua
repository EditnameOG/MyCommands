local isVisible = false

RegisterCommand("commands", function()
    isVisible = not isVisible
    SendNUIMessage({
        action = "toggle",
        visible = isVisible
    })
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if isVisible and IsControlJustReleased(0, 322) then
            isVisible = false
            SendNUIMessage({
                action = "toggle",
                visible = false
            })
        end
    end
end)

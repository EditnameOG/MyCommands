fx_version 'cerulean'
game 'gta5'

author 'Editname'
description 'MyCommands'
version '1.0.0'

client_script 'client.lua'

ui_page 'ui/index.html'

files {
    'ui/index.html'
}
